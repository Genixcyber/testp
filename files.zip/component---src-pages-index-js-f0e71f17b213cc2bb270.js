(window.webpackJsonp = window.webpackJsonp || []).push([
    [4], {
        272: function(t, n, a) {
            "use strict";
            a.r(n);
            var e = a(3),
                i = a.n(e),
                r = a(0),
                o = a.n(r),
                s = a(1),
                c = a.n(s),
                l = a(5),
                m = a(26),
                u = a(133),
                d = a(131),
                p = a(134),
                h = a(132),
                f = function(t) {
                    function n() {
                        for (var n, a = arguments.length, e = new Array(a), i = 0; i < a; i++) e[i] = arguments[i];
                        return (n = t.call.apply(t, [this].concat(e)) || this).onLinkStart = function(t, a) {
                            a.isInternal && n.secuenceElement.exit()
                        }, n
                    }
                    return i()(n, t), n.prototype.render = function() {
                        var t = this,
                            n = this.props.classes;
                        return o.a.createElement(m.a, {
                            ref: function(n) {
                                return t.secuenceElement = n
                            }
                        }, o.a.createElement("div", {
                            className: n.root
                        }, o.a.createElement("div", {
                            className: n.content
                        }, o.a.createElement(u.a, {
                            className: n.brand,
                            onLinkStart: this.onLinkStart
                        }), o.a.createElement(d.a, {
                            className: n.menu,
                            animation: {
                                duration: {
                                    enter: 400
                                }
                            },
                            scheme: "expand",
                            onLinkStart: this.onLinkStart
                        }), o.a.createElement(p.a, {
                            className: n.social,
                            onLinkStart: this.onLinkStart
                        })), o.a.createElement(h.a, {
                            className: n.legal,
                            opaque: !0,
                            onLinkStart: this.onLinkStart
                        })))
                    }, n
                }(o.a.Component);
            f.propTypes = {
                classes: c.a.any.isRequired
            }, n.default = Object(l.a)(function(t) {
                return {
                    root: {
                        margin: "auto",
                        width: "100%"
                    },
                    content: {
                        display: "flex",
                        flexDirection: "column",
                        margin: [0, "auto"],
                        padding: 20
                    },
                    brand: {
                        margin: [0, "auto", 30],
                        padding: [10, 0],
                        width: "100%",
                        maxWidth: 700
                    },
                    menu: {
                        margin: [0, "auto", 20],
                        width: "100%",
                        maxWidth: 600
                    },
                    social: {
                        margin: [0, "auto"],
                        width: "100%",
                        maxWidth: 400
                    },
                    legal: {
                        position: "absolute",
                        left: "50%",
                        bottom: 0,
                        transform: "translateX(-50%)"
                    }
                }
            })(f)
        }
    }
]);
//# sourceMappingURL=component---src-pages-index-js-f0e71f17b213cc2bb270.js.map